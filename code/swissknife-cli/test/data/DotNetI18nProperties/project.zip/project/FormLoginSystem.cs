﻿using model5335.widget;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

using model5335.app;
using model5335.doc;
using model5335.ui.more;
using model5335.dao;
using model5335.util;


namespace model5335.ui
{
    public partial class FormLoginSystem : BaseAppForm
    {

        private bool success;
        private FormLoginKeyboard formKeys;
        private AccountDoc mDoc;
        private UserDao mDao;

        public FormLoginSystem()
        {
            InitializeComponent();
            this.InitI18n();
            this.formKeys = new FormLoginKeyboard();
        }


        private DoLoginSystem GetSudo()
        {
            var apps = this.FormContext.Service;
            return new DoLoginSystem(apps);
        }


        private void buttonOK_Click(object sender, EventArgs e)
        {
            string user = this.inputUserName.Text;
            string pass = this.inputPassword.Text;
            if (this.GetSudo().Login(user, pass))
            {
                this.ShowMainForm();
            }
            else
            {
                this.ShowError();
            }
        }

        private void ShowMainForm()
        {
            this.DialogResult = DialogResult.OK;
            this.success = true;
            this.Close();
        }

        private void ShowError()
        {
            var msg = "bad uid or passwd.";
            MessageBox.Show(msg);
        }

        private void FormLoginSystem_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (!this.success)
            {
                var fc = this.FormContext;
                fc.Session.Close();
                fc.Runtime.Close();
            }
            this.formKeys.Hide();
        }

        private void FormLoginSystem_Load(object sender, EventArgs e)
        {
            this.LoadData();
            var sudo = this.GetSudo();
            string user = sudo.GetCurrentUser();
            if (user != null)
            {
                this.inputUserName.Text = user;
                this.inputUserName.ReadOnly = true;
            }
            this.formKeys.Show();
        }

        private void LoadData()
        {
            var apps = this.GetAppService();
            var dao_man = apps.GetDaoManager();
            var dao = dao_man.GetUsers();
            var doc = dao.Get();

            this.mDoc = doc;
            this.mDao = dao;

            if (doc.EnableDefaultAccount)
            {
                string pwd = null;
                var user = dao.GetDefaultAccount(out pwd);
                this.inputUserName.Text = user.UserName;
                this.inputPassword.Text = pwd;
            }

        }
    }

    class DoLoginSystem
    {
        private IAppService apps;
        private bool isOk;

        public DoLoginSystem(IAppService apps)
        {
            this.apps = apps;
            this.isOk = false;
        }

        internal bool IsOK()
        {
            return this.isOk;
        }

        internal bool Login(string user, string pass)
        {
            Account account2 = this.GetUser(user);
            Account account1 = new Account();
            account1.SetLoginParam(user, pass);
            bool ok = (account1.Check(account2));
            if (ok)
            {
                this.MakeNewSession(account2);
            }
            this.isOk = ok;
            return ok;
        }

        private void MakeNewSession(Account account)
        {
            var sm = this.apps.GetSessionManager();
            sm.NewSession(account);
        }

        private Account GetUser(string userName)
        {
            var user_dao = this.apps.GetDaoManager().GetUsers();
            var doc = user_dao.Get();
            var table = doc.accounts;
            if (table.ContainsKey(userName))
            {
                return table[userName];
            }
            else
            {
                return null;
            }
        }


        internal string GetCurrentUser()
        {
            var sm = this.apps.GetSessionManager();
            var se = sm.GetSession();
            if (se == null) return null;

            var account = se.account;
            if (account == null) return null;

            return account.UserName;
        }
    }

}
